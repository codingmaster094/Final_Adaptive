import React from 'react'
import ToolsTabsection from "@/app/components/ToolsTabsection";
export default async function Page(){
  return (
    <>
    <ToolsTabsection/>
    <div className="h-screen flex justify-center items-center p-[100px] text-h1">
    <h1>Forward Test</h1>
    </div>
    </>
  )
}
